# FoodSpots
An app for users to share their favorite food spots in the city
