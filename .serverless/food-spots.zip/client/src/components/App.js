import React, { Component } from 'react';
import logo from './../assets/logo.svg';

import Map from './Map';

class App extends Component {
  render() {
    return (
      <div>
        Hello World
        <Map/>
      </div>
    );
  }
}

export default App;
