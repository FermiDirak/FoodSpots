export default {
  google_maps_api_key: 'AIzaSyC4Li8mrhNuFLOEmn-Fcfjgb1-0jxBi7dk',
};