export default {
  google_maps_api_key: 'KEY_GOES_HERE',
};