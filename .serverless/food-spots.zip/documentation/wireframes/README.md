#/Wireframes

Any resources on the look and feel of the applicaton belong here.

----

####main-app.xml

The landing page for a user. What an average user sees when opening FoodSpots.

----
